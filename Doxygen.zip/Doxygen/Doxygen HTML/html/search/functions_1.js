var searchData=
[
  ['deletecart_112',['deleteCart',['../classdb_manager.html#a0a8828c717828246ea83f975024fb75f',1,'dbManager']]]
];
