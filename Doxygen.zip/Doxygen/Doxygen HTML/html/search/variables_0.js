var searchData=
[
  ['adminobj_173',['adminObj',['../class_main_window.html#ab89f77c0863d5be4c4669259f160746d',1,'MainWindow']]],
  ['asunum_174',['asuNum',['../classstudentpage.html#a4b122254310386b44a6369f3e3fc54f2',1,'studentpage']]]
];
