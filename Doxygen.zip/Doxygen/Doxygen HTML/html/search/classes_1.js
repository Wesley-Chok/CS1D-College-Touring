var searchData=
[
  ['dbmanager_100',['dbManager',['../classdb_manager.html',1,'']]]
];
