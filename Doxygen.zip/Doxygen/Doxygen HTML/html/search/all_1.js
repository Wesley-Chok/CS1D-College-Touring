var searchData=
[
  ['calctotaldist_4',['calcTotalDist',['../classstudentpage.html#a35e79f7bcfedaaa79b8b0c795b6ddc5c',1,'studentpage']]],
  ['campus_5',['campus',['../structstudentpage_1_1_souvenir.html#ad25886e842e87df5c991e79716e9fca2',1,'studentpage::Souvenir']]],
  ['changetoadminhomepage_6',['changeToAdminHomePage',['../classadminpage.html#a045eab519d3e0cd10b85b489289191a8',1,'adminpage']]],
  ['changetosouvenirdeletepage_7',['changeToSouvenirDeletePage',['../classadminpage.html#ad539e0dd6a057018b02e525fa8466926',1,'adminpage']]],
  ['changetosouvenirpage_8',['changeToSouvenirPage',['../classadminpage.html#a96344db537e4f10c0ef864fe715b3cb1',1,'adminpage']]],
  ['changetosouvenirpricepage_9',['changeToSouvenirPricePage',['../classadminpage.html#a0364f216df203c3a49472c10fc7baa13',1,'adminpage']]],
  ['checkcampusname_10',['checkCampusName',['../classdb_manager.html#a83cac4edd98c0ff51ec1730db5af2e5a',1,'dbManager']]],
  ['checkcampusvectornames_11',['checkCampusVectorNames',['../classstudentpage.html#aa59678b46936fdd564ab714a624df497',1,'studentpage']]],
  ['cost_12',['cost',['../structstudentpage_1_1_souvenir.html#aed020293faee196861633045cc811062',1,'studentpage::Souvenir']]],
  ['createcart_13',['createCart',['../classdb_manager.html#a092fd94dfc8761dc238a20bc20855fdc',1,'dbManager']]],
  ['custom_14',['custom',['../classstudentpage.html#a2b3cace0455ac189a3d30297ce85b749aac4534060fd536012fa9d3ecb5090cdd',1,'studentpage']]]
];
