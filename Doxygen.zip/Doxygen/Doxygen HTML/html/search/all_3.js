var searchData=
[
  ['getcampuscount_19',['GetCampusCount',['../classdb_manager.html#a90d87c0fdcd4458d916786495f9b552a',1,'dbManager']]],
  ['getdistbtwn_20',['GetDistBtwn',['../classdb_manager.html#aa797049558e234dd8b8b7cf542c388d4',1,'dbManager']]],
  ['gettotalcost_21',['GetTotalCost',['../classdb_manager.html#a279ddab2e19733d36baea2b7d3721364',1,'dbManager']]],
  ['gotosouvenirshop_22',['goToSouvenirShop',['../classstudentpage.html#a43e65f8deed28d335c0883d0e1fd0d08',1,'studentpage']]]
];
