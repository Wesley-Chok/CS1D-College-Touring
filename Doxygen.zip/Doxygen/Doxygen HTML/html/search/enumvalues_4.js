var searchData=
[
  ['uci_197',['uci',['../classstudentpage.html#a2b3cace0455ac189a3d30297ce85b749a1bdc06fb8ca84a0c28246848458bd0f7',1,'studentpage']]]
];
