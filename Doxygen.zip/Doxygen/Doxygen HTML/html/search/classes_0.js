var searchData=
[
  ['adminpage_99',['adminpage',['../classadminpage.html',1,'']]]
];
