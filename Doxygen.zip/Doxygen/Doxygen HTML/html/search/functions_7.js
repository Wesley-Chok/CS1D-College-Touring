var searchData=
[
  ['updatecartquantity_172',['updateCartQuantity',['../classdb_manager.html#a1d7cf5b8b1eacb01059e9b7f026a0ebb',1,'dbManager']]]
];
