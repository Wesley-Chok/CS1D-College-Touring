var searchData=
[
  ['quantity_65',['quantity',['../structstudentpage_1_1_souvenir.html#a3f4c9cb1c165b3823c6c5c0dbb45068e',1,'studentpage::Souvenir']]]
];
