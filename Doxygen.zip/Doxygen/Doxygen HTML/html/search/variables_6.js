var searchData=
[
  ['ui_191',['ui',['../classadminpage.html#a8d6a397dd879be7a9c24b850a81f58ec',1,'adminpage::ui()'],['../class_main_window.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow::ui()'],['../classstudentpage.html#a5776b8fb9c59087a11eae9f8dd442551',1,'studentpage::ui()']]]
];
