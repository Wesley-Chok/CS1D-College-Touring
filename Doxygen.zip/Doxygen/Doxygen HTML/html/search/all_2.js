var searchData=
[
  ['database_15',['database',['../classstudentpage.html#abb94d0981d09cca8afad8e68edf32e20',1,'studentpage']]],
  ['database_5f_16',['database_',['../classadminpage.html#a03256ef1acb5190d7e02f26270974a41',1,'adminpage']]],
  ['dbmanager_17',['dbManager',['../classdb_manager.html',1,'']]],
  ['deletecart_18',['deleteCart',['../classdb_manager.html#a0a8828c717828246ea83f975024fb75f',1,'dbManager']]]
];
