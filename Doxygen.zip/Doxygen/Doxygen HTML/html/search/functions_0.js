var searchData=
[
  ['calctotaldist_104',['calcTotalDist',['../classstudentpage.html#a35e79f7bcfedaaa79b8b0c795b6ddc5c',1,'studentpage']]],
  ['changetoadminhomepage_105',['changeToAdminHomePage',['../classadminpage.html#a045eab519d3e0cd10b85b489289191a8',1,'adminpage']]],
  ['changetosouvenirdeletepage_106',['changeToSouvenirDeletePage',['../classadminpage.html#ad539e0dd6a057018b02e525fa8466926',1,'adminpage']]],
  ['changetosouvenirpage_107',['changeToSouvenirPage',['../classadminpage.html#a96344db537e4f10c0ef864fe715b3cb1',1,'adminpage']]],
  ['changetosouvenirpricepage_108',['changeToSouvenirPricePage',['../classadminpage.html#a0364f216df203c3a49472c10fc7baa13',1,'adminpage']]],
  ['checkcampusname_109',['checkCampusName',['../classdb_manager.html#a83cac4edd98c0ff51ec1730db5af2e5a',1,'dbManager']]],
  ['checkcampusvectornames_110',['checkCampusVectorNames',['../classstudentpage.html#aa59678b46936fdd564ab714a624df497',1,'studentpage']]],
  ['createcart_111',['createCart',['../classdb_manager.html#a092fd94dfc8761dc238a20bc20855fdc',1,'dbManager']]]
];
